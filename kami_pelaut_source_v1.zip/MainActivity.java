package com.kamipelaut;

public class MainActivity {
    public static void main(String[] args) {
        System.out.println("Kami Pelaut App v1.0");
    }
}