Cara build:
1. Buka dengan Android Studio
2. Sync Gradle
3. Klik Build > Build APK
4. APK hasil ada di /app/build/outputs/apk/